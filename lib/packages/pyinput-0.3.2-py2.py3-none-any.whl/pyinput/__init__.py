__version__ = "0.3.2"
__description__ = "Python library to send inputs to an executable, useful for scenarios such as having a neural network send decisions to a game. Essentially a wrapper around the win32api."
__author__ = 'Gary Frazier'